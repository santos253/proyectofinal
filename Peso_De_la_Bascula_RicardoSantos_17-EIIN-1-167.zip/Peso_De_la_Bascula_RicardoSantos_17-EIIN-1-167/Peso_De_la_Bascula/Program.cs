﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Peso_De_la_Bascula
{
    class Program
    {
        static void Main(string[] args)
        {
            int noMiembro = 1;
            List<Miembro> listaMiembros = new List<Miembro>();//creando una lista para todos los miembros.

            //imprime la informacion del estudiante
            Console.WriteLine("Nombre: Ricardo Santos");
            Console.WriteLine("Matricula: 17-EIIN-1");


            Console.WriteLine("MENU");
            Console.WriteLine("---------------");
            Console.WriteLine("RESULTADOS  (R)");
            Console.WriteLine("SALIR       (X)");
            Console.WriteLine(" ");

            while (noMiembro < 3)
            {//recorriendo el numero de miembros


                Console.WriteLine("MIEMBRO NO: " + noMiembro);
                Miembro m = new Miembro();
                Console.WriteLine("");

                Console.WriteLine("> Ultimo Peso: ");

                double ultimoPeso = m.validarEntrada(listaMiembros); //validando lo que el usuario esta digitando, sea para ver los resultados como para salir del sistema.
                double totalPeso = 0;

                for (int bascula = 1; bascula <= 4; bascula++)
                {//recorriendo el numero de basculas con sus respectivos pesos

                    Console.WriteLine("> Introduzca el peso de la bascula : " + bascula);
                    totalPeso += m.validarEntrada(listaMiembros);
                    m.setProp(noMiembro, ultimoPeso, totalPeso);//cada ves que el miembro se pesa se agrega como una propiedad nueva para este miembro
                }
                listaMiembros.Add(m);//agregamos este nuevo miembro a la lista de miembros disponibles.
                noMiembro++;
            }

            foreach (Miembro miembro in listaMiembros)
            {//finalmente recorremos todos los miembros con sus pesos y caracteristicas.
                Console.WriteLine("");
                Console.WriteLine(miembro.getResult());
            }


        }//fin main method



        class Miembro
        {//clase que gestiona las propiedades de cada miembro, dependiendo del promedio del peso por basculas se determinara si perdio o gano peso.

            private int noMiembro;
            private double ultimoPeso;
            private double totalPeso;

            public void setProp(int noMiembro, double ultimoPeso, double totalPeso)
            {
                this.noMiembro = noMiembro;
                this.ultimoPeso = ultimoPeso;
                this.totalPeso = totalPeso;
            }

            private int getNoMiembro()
            {
                return this.noMiembro;
            }
            private double getUltimoPeso()
            {
                return this.ultimoPeso;
            }

            public string getResult()
            {

                double promedio = totalPeso / 4;

                if (promedio < this.getUltimoPeso())
                {
                    return "El miembro No. " + this.getNoMiembro() + " BAJO DE PESO";
                }

                return "El miembro No. " + this.getNoMiembro() + " SUBIO DE PESO";
            }


            public double validarEntrada(List<Miembro> listaMiembros)
            {//funcion que valida la entrada del usuario por teclado, si el usuario decide terminar el programa se imprimen los resultados disponibles.

                double a;
                string n = "";

                while (!double.TryParse(n, out a))
                {//valida si es numerico

                    n = Console.ReadLine();

                    if (n.ToUpper() == "R" || n.ToUpper() == "X")
                    {

                        foreach (Miembro miembro in listaMiembros)
                        {
                            Console.WriteLine("");
                            Console.WriteLine(miembro.getResult());
                        }

                        Console.WriteLine("Fin del programa");

                    }
                }

                return a;

            }

        }//fin clase Miembro

    }//fin clase principal

}
    

